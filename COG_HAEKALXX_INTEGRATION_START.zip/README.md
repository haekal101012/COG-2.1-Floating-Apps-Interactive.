# COG — Country of Gamers

Developer credit: **HAEKALXX**.

## Build APK with GitHub Actions
1. Upload the contents of this project to the repository root (the `app/`, `build.gradle`, `settings.gradle`, and `gradle.properties` files must be at the root).
2. Open Actions → Build COG APK → Run workflow.
3. Download artifact `COG-New-Floating-APK`.

## Current implementation notes
- The app includes a native neon-styled home screen and floating overlay UI.
- The crosshair is a visual overlay only.
- The existing Macro area in `FloatingService` is still configuration-slot UI; it does **not** yet implement real hardware key capture or touch injection. Do not treat those controls as a working macro engine.
- Shizuku integration is not present in this source snapshot. A connected/active Shizuku state must not be shown until the official API is integrated and the permission state is checked.
- `minSdk` is 24 to align with the Shizuku API requirement planned for integration.
