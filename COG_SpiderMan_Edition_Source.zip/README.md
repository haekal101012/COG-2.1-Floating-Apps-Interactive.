# COG — Spider-Man Edition (HAEKALXX)

Theme refresh of the provided COG Android source: dark black/red palette, red spider-web wallpaper, and Spider Web branding.

## Build
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- Run `gradle assembleDebug` or use `.github/workflows/build-apk.yml`.

## Important
- This source ZIP was edited, but it has **not been compiled or tested on a device in this session**. Use GitHub Actions to verify the build.
- The existing bundled videos remain `ambient_flow.mp4` and `hunt_showdown.mp4`; the new video files were not provided with this upload, so they have not been replaced.
- The existing macro UI remains configuration-only; arbitrary cross-app input injection is not implemented.
- FPS is a target label, not measured game telemetry.
