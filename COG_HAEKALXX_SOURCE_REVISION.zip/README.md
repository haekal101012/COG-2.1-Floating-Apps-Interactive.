# COG — HAEKALXX (source revision)

Android project source for the COG floating utility.

## Build
Run `gradle assembleDebug --no-daemon` from this directory, or use the included GitHub Actions workflow.

## Important implementation status
- Responsive overlay bounds and removal of `FLAG_LAYOUT_NO_LIMITS` have been updated to reduce off-screen/clipped windows.
- STOP path removes known overlay views (panel, crosshair, bubble), clears crosshair preference, stops foreground mode, and stops the service.
- Macro slots currently save enable preference and a configurable interval (20–5000 ms) only. The UI explicitly reports that cross-app physical key mapping and touch injection are NOT implemented in this build. Do not treat the Enabled switch as an active macro.
- Shizuku API integration is not present in this source revision.

This is not a release-certified/final APK. Validate on a physical Android device and inspect GitHub Actions after pushing. Build success alone does not verify overlay behavior.
