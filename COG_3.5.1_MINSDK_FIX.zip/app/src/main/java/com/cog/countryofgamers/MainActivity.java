package com.cog.countryofgamers;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityManager;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Debug;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import rikka.shizuku.Shizuku;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int cyan=Color.rgb(0,229,255), purple=Color.rgb(164,75,255), ink=0xff06101f;
    private LinearLayout root, nav; private int current=0;
    private TextView shizukuStatusView;
    private static final int SHIZUKU_PERMISSION_REQUEST = 7301;
    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if (requestCode == SHIZUKU_PERMISSION_REQUEST) {
            refreshShizukuStatus();
            Toast.makeText(this, grantResult == PackageManager.PERMISSION_GRANTED ? "Izin Shizuku diberikan" : "Izin Shizuku ditolak", Toast.LENGTH_SHORT).show();
        }
    };
    private final Runnable shizukuBinderReceivedListener = () -> runOnUiThread(this::refreshShizukuStatus);
    private final Runnable shizukuBinderDeadListener = () -> runOnUiThread(this::refreshShizukuStatus);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff030713); getWindow().setNavigationBarColor(0xff030713);
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderReceivedListener);
        Shizuku.addBinderDeadListener(shizukuBinderDeadListener);
        render();
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);
    }
    @Override protected void onResume() { super.onResume(); refreshShizukuStatus(); }
    @Override protected void onDestroy() {
        Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);
        Shizuku.removeBinderReceivedListener(shizukuBinderReceivedListener);
        Shizuku.removeBinderDeadListener(shizukuBinderDeadListener);
        super.onDestroy();
    }
    private void render(){
        FrameLayout frame=new FrameLayout(this); ImageView wallpaper=new ImageView(this); wallpaper.setImageResource(R.drawable.cog_background); wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP); frame.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1)); View shade=new View(this); shade.setBackgroundColor(0xe6030714); frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout shell=new LinearLayout(this); shell.setOrientation(LinearLayout.VERTICAL); frame.addView(shell,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL); brand.setPadding(dp(16),dp(13),dp(16),dp(13)); brand.setBackground(bg(true)); TextView logo=txt("COG",29,true); logo.setShadowLayer(dp(7),0,0,cyan); brand.addView(logo); LinearLayout names=new LinearLayout(this); names.setOrientation(LinearLayout.VERTICAL); names.setPadding(dp(12),0,0,0); names.addView(txt("COUNTRY OF GAMERS",16,true)); TextView sub=txt("3-PAGE GAMING TOOLKIT",10,true);sub.setTextColor(cyan);names.addView(sub);brand.addView(names,new LinearLayout.LayoutParams(0,-2,1)); shell.addView(brand,lp(-1,-2,12,12,12,10));
        nav=new LinearLayout(this); nav.setOrientation(LinearLayout.HORIZONTAL); String[] tabs={"DEBUGGING","GAME LAUNCHER","SETTINGS"}; for(int i=0;i<tabs.length;i++){ final int idx=i; Button b=btn(tabs[i],i==current); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(44),1);p.setMargins(dp(2),0,dp(2),0);nav.addView(b,p);b.setOnClickListener(v->{current=idx;render();}); } shell.addView(nav,lp(-1,-2,10,0,10,8));
        ScrollView sc=new ScrollView(this); sc.setFillViewport(false); shell.addView(sc,new LinearLayout.LayoutParams(-1,0,1)); root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(14),dp(4),dp(14),dp(22));sc.addView(root);
        if(current==0) pageDebug(); else if(current==1) pageGames(); else pageSettings();
        setContentView(frame);
    }
    private void pageDebug(){
        hero("01  /  DEBUGGING","SHIZUKU & WIRELESS DEBUGGING","Panduan sambungan dan akses sistem. Status di bawah tidak akan mengaku terhubung tanpa pemeriksaan nyata.");
        cardTitle("SHIZUKU SETUP","ADB permission bridge"); addText("1. Aktifkan Developer options dan Wireless debugging di pengaturan Android.\n2. Buka Shizuku lalu pilih Pairing.\n3. Pasangkan melalui kode pairing dari notifikasi Wireless debugging.\n4. Kembali ke Shizuku dan tekan Start. Setelah reboot, layanan mungkin perlu dijalankan lagi.",12,0xffd5e2f7);
        Button guide=btn("BUKA PANDUAN RESMI SHIZUKU ↗",true);root.addView(guide,lp(-1,48,0,12,0,8));guide.setOnClickListener(v->openUrl("https://shizuku.rikka.app/guide/setup/"));
        Button wireless=btn("BUKA PENGATURAN WIRELESS DEBUGGING",false);root.addView(wireless,lp(-1,46,0,0,0,8));wireless.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.R){try{startActivity(new Intent("android.settings.APPLICATION_DEVELOPMENT_SETTINGS"));}catch(Exception e){openSettings();}}else openSettings();});
        cardTitle("LIVE SHIZUKU STATUS","Read from Shizuku API");
        shizukuStatusView=txt("Memeriksa status Shizuku…",13,true); shizukuStatusView.setTextColor(cyan); shizukuStatusView.setPadding(dp(4),dp(8),dp(4),dp(10)); root.addView(shizukuStatusView,lp(-1,-2,0,0,0,4));
        Button checkShizuku=btn("REFRESH SHIZUKU STATUS",false); root.addView(checkShizuku,lp(-1,44,0,0,0,8)); checkShizuku.setOnClickListener(v->refreshShizukuStatus());
        Button grantShizuku=btn("REQUEST / OPEN SHIZUKU PERMISSION",true); root.addView(grantShizuku,lp(-1,46,0,0,0,8)); grantShizuku.setOnClickListener(v->requestShizukuPermission());
        addText("Status ini memeriksa Binder dan izin API Shizuku. Pairing Wireless Debugging tetap dilakukan di aplikasi Shizuku; COG tidak bisa memastikan status toggle Wireless Debugging melalui API publik umum.",11,0xffc4d4ee);
        Button overlay=btn("IZINKAN FLOATING OVERLAY",false);root.addView(overlay,lp(-1,46,0,12,0,8));overlay.setOnClickListener(v->permission());
    }
    private void pageGames(){
        hero("02  /  GAME LAUNCHER","YOUR INSTALLED GAMES","Daftar dibuat dari aplikasi yang dapat diluncurkan di perangkat ini. Ketuk OPEN untuk menjalankan aplikasi.");
        Button refresh=btn("↻  REFRESH APP LIST",true);root.addView(refresh,lp(-1,46,0,0,0,10));refresh.setOnClickListener(v->{current=1;render();});
        List<ApplicationInfo> apps=new ArrayList<>(); PackageManager pm=getPackageManager(); for(ApplicationInfo a:pm.getInstalledApplications(PackageManager.GET_META_DATA)){ if(pm.getLaunchIntentForPackage(a.packageName)!=null && !getPackageName().equals(a.packageName)) apps.add(a); }
        Collections.sort(apps,new Comparator<ApplicationInfo>(){public int compare(ApplicationInfo a,ApplicationInfo b){return pm.getApplicationLabel(a).toString().compareToIgnoreCase(pm.getApplicationLabel(b).toString());}});
        int shown=0;for(ApplicationInfo a:apps){String name=pm.getApplicationLabel(a).toString(); boolean system=(a.flags&ApplicationInfo.FLAG_SYSTEM)!=0; if(system && shown>8)continue; LinearLayout c=card();c.setOrientation(LinearLayout.HORIZONTAL);c.setGravity(Gravity.CENTER_VERTICAL);c.setPadding(dp(12),dp(10),dp(10),dp(10)); TextView icon=new TextView(this);icon.setText("▣");icon.setTextColor(cyan);icon.setTextSize(23);c.addView(icon);LinearLayout words=new LinearLayout(this);words.setOrientation(LinearLayout.VERTICAL);words.setPadding(dp(10),0,dp(5),0);words.addView(txt(name,14,true));TextView pkg=txt(a.packageName,9,false);pkg.setTextColor(0xff9eb3d4);words.addView(pkg);c.addView(words,new LinearLayout.LayoutParams(0,-2,1));Button open=btn("OPEN",false);c.addView(open, new LinearLayout.LayoutParams(dp(74),dp(40)));open.setOnClickListener(v->launch(a.packageName));root.addView(c,lp(-1,-2,0,0,0,7));shown++;}
        if(shown==0)addText("Tidak ada aplikasi yang dapat diluncurkan ditemukan.",13,Color.WHITE);
        addText("Catatan: Android dapat menyembunyikan sebagian paket aplikasi dari daftar. Game yang terpasang dan bisa dibuka akan muncul sesuai akses PackageManager.",10,0xff9eb3d4);
    }
    private void pageSettings(){
        hero("03  /  SETTINGS & MONITORING","DEVICE CONTROL DECK","Pengaturan COG dan informasi perangkat yang dibaca dari Android. Ini bukan pengukur FPS game.");
        cardTitle("OVERLAY SETTINGS","Floating control center"); Button start=btn("▶  START COG FLOATING WINDOW",true);root.addView(start,lp(-1,50,0,0,0,8));start.setOnClickListener(v->startOverlay());Button stop=btn("■  STOP COG OVERLAY",false);root.addView(stop,lp(-1,46,0,0,0,8));stop.setOnClickListener(v->{stopService(new Intent(this,FloatingService.class));Toast.makeText(this,"COG overlay dihentikan",Toast.LENGTH_SHORT).show();});Button perm=btn("MANAGE OVERLAY PERMISSION",false);root.addView(perm,lp(-1,46,0,0,0,14));perm.setOnClickListener(v->permission());
        cardTitle("LIVE DEVICE INFO","Android system readings"); addText("Android version: "+Build.VERSION.RELEASE+" (API "+Build.VERSION.SDK_INT+")\nDevice: "+Build.MANUFACTURER+" "+Build.MODEL+"\nArchitecture: "+System.getProperty("os.arch","N/A"),12,0xffd5e2f7);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo();((ActivityManager)getSystemService(ACTIVITY_SERVICE)).getMemoryInfo(mi);addMetric("RAM TOTAL",formatBytes(mi.totalMem),"RAM AVAILABLE",formatBytes(mi.availMem));
        try{StatFs fs=new StatFs(Environment.getDataDirectory().getPath());addMetric("STORAGE TOTAL",formatBytes(fs.getTotalBytes()),"STORAGE FREE",formatBytes(fs.getAvailableBytes()));}catch(Exception e){addMetric("STORAGE","N/A","STORAGE FREE","N/A");}
        android.util.DisplayMetrics dm=new android.util.DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(dm);addMetric("DISPLAY",dm.widthPixels+" × "+dm.heightPixels,"DENSITY",String.format(Locale.US,"%.1f dpi",dm.densityDpi));
        cardTitle("LIMITATIONS","No fabricated telemetry");addText("FPS game, ping server, dan suhu CPU tidak ditampilkan karena COG belum punya sumber pengukuran yang andal untuk data tersebut. Slider utilitas COG juga tidak otomatis mengubah sensitivitas internal game.",11,0xffaebfdb);
        Button shizuku=btn("SHIZUKU OFFICIAL GUIDE ↗",false);root.addView(shizuku,lp(-1,44,0,12,0,8));shizuku.setOnClickListener(v->openUrl("https://shizuku.rikka.app/guide/setup/"));
    }
    private void hero(String tag,String title,String desc){LinearLayout c=card();c.setPadding(dp(15),dp(16),dp(15),dp(16));TextView t=txt(tag,10,true);t.setTextColor(cyan);c.addView(t);TextView h=txt(title,23,true);h.setPadding(0,dp(7),0,dp(5));h.setShadowLayer(dp(4),0,0,0xff243eff);c.addView(h);TextView d=txt(desc,12,false);d.setTextColor(0xffc2d1e9);c.addView(d);root.addView(c,lp(-1,-2,0,0,0,14));}
    private void cardTitle(String title,String sub){LinearLayout c=card();c.setPadding(dp(13),dp(12),dp(13),dp(12));TextView h=txt(title,14,true);h.setTextColor(cyan);c.addView(h);TextView s=txt(sub,10,true);s.setTextColor(0xff9fb6d9);c.addView(s);root.addView(c,lp(-1,-2,0,0,0,8));}
    private void addText(String s,int size,int color){TextView t=txt(s,size,false);t.setTextColor(color);t.setPadding(dp(4),dp(5),dp(4),dp(9));root.addView(t,lp(-1,-2,0,0,0,6));}
    private void addMetric(String a,String av,String b,String bv){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);row.addView(metric(a,av),new LinearLayout.LayoutParams(0,-2,1));row.addView(metric(b,bv),new LinearLayout.LayoutParams(0,-2,1));root.addView(row,lp(-1,-2,0,0,0,8));}
    private View metric(String title,String value){LinearLayout c=card();c.setPadding(dp(11),dp(11),dp(8),dp(11));TextView t=txt(title,9,true);t.setTextColor(0xffa7bbd9);c.addView(t);TextView v=txt(value,15,true);v.setTextColor(cyan);c.addView(v);return c;}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackground(bg(false));return l;}
    private GradientDrawable bg(boolean head){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,head?new int[]{0xf00a2638,0xf00b0c25,0xf01a0a32}:new int[]{0xee07172b,0xf0060b1b,0xee100a27});d.setCornerRadius(dp(head?18:14));d.setStroke(dp(1),head?cyan:0xff176b91);return d;}
    private TextView txt(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private Button btn(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(10);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,primary?new int[]{0xff007fc9,0xff1746cc,0xff6921c4}:new int[]{0xff0b233b,0xff11152d,0xff1a1030});d.setCornerRadius(dp(11));d.setStroke(dp(1),primary?cyan:purple);b.setBackground(d);return b;}
    private LinearLayout.LayoutParams lp(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private void refreshShizukuStatus() {
        if (shizukuStatusView == null) return;
        String status;
        boolean managerInstalled;
        try { getPackageManager().getPackageInfo("moe.shizuku.privileged.api", 0); managerInstalled=true; }
        catch (PackageManager.NameNotFoundException e) { managerInstalled=false; }
        boolean binderAlive=false;
        try { binderAlive=Shizuku.pingBinder(); } catch (Throwable ignored) {}
        if (!managerInstalled && !binderAlive) {
            status="● SHIZUKU MANAGER TIDAK TERDETEKSI\nInstal Shizuku dari sumber resminya, lalu jalankan servicenya.";
        } else if (!binderAlive) {
            status="● SHIZUKU TERPASANG, SERVICE BELUM AKTIF\nBuka Shizuku dan tekan Start. Setelah reboot, service mungkin perlu dijalankan lagi.";
        } else {
            try {
                if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                    status="● BINDER AKTIF · IZIN COG DIBERIKAN\nCOG dapat memanggil API Shizuku yang diizinkan.";
                } else {
                    status="● BINDER AKTIF · IZIN COG BELUM DIBERIKAN\nTekan Request Permission untuk memberi izin.";
                }
            } catch (Throwable e) {
                status="● BINDER AKTIF · STATUS IZIN TIDAK DAPAT DIBACA\nCoba buka ulang Shizuku dan refresh.";
            }
        }
        shizukuStatusView.setText(status);
    }
    private void requestShizukuPermission() {
        boolean alive=false;
        try { alive=Shizuku.pingBinder(); } catch (Throwable ignored) {}
        if (!alive) {
            refreshShizukuStatus();
            Toast.makeText(this,"Aktifkan service Shizuku terlebih dahulu",Toast.LENGTH_LONG).show();
            try { startActivity(getPackageManager().getLaunchIntentForPackage("moe.shizuku.privileged.api")); } catch (Exception ignored) { openUrl("https://shizuku.rikka.app/download/"); }
            return;
        }
        try {
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this,"Izin Shizuku untuk COG sudah diberikan",Toast.LENGTH_SHORT).show();
                refreshShizukuStatus();
            } else {
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST);
            }
        } catch (Throwable e) {
            Toast.makeText(this,"Tidak bisa meminta izin Shizuku: "+e.getClass().getSimpleName(),Toast.LENGTH_LONG).show();
        }
    }
    private void permission(){if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this))startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));else Toast.makeText(this,"Izin overlay sudah tersedia",Toast.LENGTH_SHORT).show();}
    private void openSettings(){try{startActivity(new Intent(Settings.ACTION_SETTINGS));}catch(Exception ignored){}}
    private void openUrl(String u){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(u)));}catch(Exception e){Toast.makeText(this,"Browser tidak tersedia",Toast.LENGTH_SHORT).show();}}
    private void launch(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i!=null)startActivity(i);else Toast.makeText(this,"Tidak ada launcher untuk aplikasi ini",Toast.LENGTH_SHORT).show();}catch(Exception e){Toast.makeText(this,"Tidak bisa membuka aplikasi",Toast.LENGTH_SHORT).show();}}
    private void startOverlay(){if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){permission();return;}Intent i=new Intent(this,FloatingService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"COG overlay dimulai",Toast.LENGTH_SHORT).show();}
}
