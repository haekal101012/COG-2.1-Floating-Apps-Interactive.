# COG — Country of Gamers (New Repository)

Native Android floating gaming utility overlay. Includes the generated COG neon background asset, draggable bubble/panel, foreground service, utility pages, and GitHub Actions build.

## Build
Push to `main`, then GitHub Actions builds `app-debug.apk` and uploads artifact `COG-New-Floating-APK`.

## Safety scope
Visual overlay, configuration, profiles, device/network display, and launching real installed apps. No automated gameplay input, aim assistance, memory manipulation, or anti-cheat bypass.
