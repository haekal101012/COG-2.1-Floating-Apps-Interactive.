package com.cog.countryofgamers;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32,40,32,32); root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Color.rgb(5,9,20));
        TextView title = new TextView(this); title.setText("COG\nCOUNTRY OF GAMERS"); title.setTextColor(Color.WHITE); title.setTextSize(28); title.setGravity(Gravity.CENTER); root.addView(title, new LinearLayout.LayoutParams(-1,-2));
        TextView sub = new TextView(this); sub.setText("Floating Control Center • visual overlay only"); sub.setTextColor(Color.rgb(145,164,194)); sub.setGravity(Gravity.CENTER); sub.setPadding(0,12,0,28); root.addView(sub);
        Button perm = new Button(this); perm.setText("1. ALLOW DISPLAY OVER OTHER APPS"); root.addView(perm, lp());
        Button start = new Button(this); start.setText("2. START COG FLOATING"); root.addView(start, lp());
        Button stop = new Button(this); stop.setText("STOP COG"); root.addView(stop, lp());
        perm.setOnClickListener(v -> { if (Build.VERSION.SDK_INT >= 23) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); });
        start.setOnClickListener(v -> { if (Settings.canDrawOverlays(this)) { if (Build.VERSION.SDK_INT >= 26) startForegroundService(new Intent(this,FloatingService.class)); else startService(new Intent(this,FloatingService.class)); } else perm.performClick(); });
        stop.setOnClickListener(v -> stopService(new Intent(this,FloatingService.class)));
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 44);
        setContentView(root);
    }
    private LinearLayout.LayoutParams lp(){ LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,56); p.setMargins(0,10,0,10); return p; }
}
