package com.cog.countryofgamers;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.VideoView;
import android.media.MediaPlayer;

/** Muted opening video for COG. It advances to HOME on completion or playback error. */
public class SplashActivity extends Activity {
    private VideoView introVideo;
    private boolean movedToHome=false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Window w=getWindow();
        w.setStatusBarColor(Color.rgb(3,7,18));
        w.setNavigationBarColor(Color.rgb(3,7,18));
        w.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        FrameLayout root=new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(3,7,18));
        introVideo=new VideoView(this);
        root.addView(introVideo,new FrameLayout.LayoutParams(-1,-1));

        View shade=new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
            new int[]{0x8a030718,0x10030712,0xc9030718}));
        root.addView(shade,new FrameLayout.LayoutParams(-1,-1));

        TextView brand=new TextView(this);
        brand.setText("COG\nCOUNTRY OF GAMERS\nNEON BLADE • HAEKALXX");
        brand.setTextColor(Color.WHITE); brand.setTextSize(22);
        brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        brand.setGravity(Gravity.CENTER); brand.setShadowLayer(10,0,0,0xff087fbd);
        FrameLayout.LayoutParams brandLp=new FrameLayout.LayoutParams(-1,-2,Gravity.CENTER);
        brandLp.setMargins(28,0,28,0); root.addView(brand,brandLp);

        TextView skip=new TextView(this);
        skip.setText("LEWATI  ›"); skip.setTextColor(Color.WHITE); skip.setTextSize(13);
        skip.setTypeface(Typeface.DEFAULT,Typeface.BOLD); skip.setGravity(Gravity.CENTER);
        skip.setPadding(26,14,26,14);
        GradientDrawable buttonBg=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
            new int[]{0xff006dcb,0xff5520b7});
        buttonBg.setCornerRadius(40); buttonBg.setStroke(2,0xff00beff); skip.setBackground(buttonBg);
        FrameLayout.LayoutParams skipLp=new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.END);
        skipLp.setMargins(0,0,22,28); root.addView(skip,skipLp);
        skip.setOnClickListener(v->openHome());

        setContentView(root);
        introVideo.setOnPreparedListener(mp->{mp.setVolume(0f,0f);introVideo.start();});
        introVideo.setOnCompletionListener(mp->openHome());
        introVideo.setOnErrorListener((mp,what,extra)->{openHome();return true;});
        introVideo.setVideoURI(Uri.parse("android.resource://"+getPackageName()+"/"+R.raw.ambient_flow));
    }

    private void openHome() {
        if(movedToHome || isFinishing()) return;
        movedToHome=true;
        try { if(introVideo!=null) introVideo.stopPlayback(); } catch(Exception ignored) {}
        startActivity(new Intent(this,MainActivity.class));
        finish();
    }

    @Override protected void onPause(){if(introVideo!=null){try{introVideo.pause();}catch(Exception ignored){}}super.onPause();}
    @Override protected void onDestroy(){if(introVideo!=null){try{introVideo.stopPlayback();}catch(Exception ignored){}}getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);super.onDestroy();}
}
