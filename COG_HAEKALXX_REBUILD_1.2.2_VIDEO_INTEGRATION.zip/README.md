# COG — Country of Gamers (HAEKALXX)

Neon Blade Android overlay project. Android Studio/Gradle project files are at the ZIP root.

## Video integration in this source
- `Ambient_Flow_video_no_watermark.mp4` is bundled as `res/raw/ambient_flow.mp4` and played muted on the app's launch screen. It automatically continues to HOME when playback finishes; a LEWATI button is available.
- `Hunt_Showdown_video_no_watermark.mp4` is bundled as `res/raw/hunt_showdown.mp4` and plays muted in the wide HOME showcase card, replacing the blank graphic area. It loops while HOME is visible.
- Both video cards use COG's navy/cyan-violet frame treatment so they visually match the rest of the app. The static wallpaper remains dark and stable; no flashing tint animation is added by this video integration.

## Build
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- `gradle assembleDebug`

## Important limitations
- This source has not been compiled in an Android SDK environment in this session. Run the included GitHub Actions workflow to verify compilation.
- Existing macro options are configuration UI only; cross-app hardware-key listening, hold/release detection and touch injection are not implemented by this revision. Shizuku alone does not guarantee arbitrary cross-app input injection.
- Wireless debugging pairing still requires Android/Shizuku user steps; the app cannot silently force the system pairing dialog.
- FPS/ping are not claimed as measured game telemetry.
