# COG — Country of Gamers (HAEKALXX)

COG Neon Blade Android source project. This archive is structured with `settings.gradle` at its root so GitHub Actions can build it after you upload the extracted contents to the repository root.

## Build using GitHub Actions
1. Extract this ZIP.
2. Upload the contents (not the enclosing folder) to the root of your GitHub repository.
3. Open Actions and run **Build COG APK**.
4. Download artifact `COG-New-Floating-APK` if the workflow succeeds.

## What this revision contains
- Native HOME screen and interactive bottom navigation.
- Floating COG bubble and a right-edge handle; swipe the handle inward or tap it to open/close the control panel.
- Crosshair overlay with saved size, gap, and thickness settings.
- Dynamic list of installed activities that can be launched.
- Shizuku installed/binder/permission status checks and shortcuts to Shizuku / Android developer settings.
- Macro configuration slots with saved Tap/Hold/Repeat selection and interval validation.
- Device information based on Android APIs and saved profiles with DEV credit HAEKALXX.
- STOP cleanup for panel, crosshair, edge handle, bubble, and foreground service.

## Important limitations — read before calling this final
- Macro settings are configuration only in this build. Cross-app hardware-key capture, reliable key-release detection, and arbitrary touch injection are not implemented. The UI does not claim that a macro is executing.
- Wireless Debugging pairing still requires the user to complete Android/Shizuku's pairing steps; COG does not bypass OS security.
- FPS and in-game ping are not measured. Only device values available through Android APIs are shown.
- This source was not compiled in this environment because a local Android/Gradle build toolchain is unavailable. The GitHub Actions run must succeed before treating the APK as build-verified, and device testing is still required.
