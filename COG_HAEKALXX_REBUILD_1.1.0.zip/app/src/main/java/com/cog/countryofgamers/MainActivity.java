package com.cog.countryofgamers;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int cyan=Color.rgb(0,190,255), purple=Color.rgb(151,55,255);
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(3,7,18)); getWindow().setNavigationBarColor(Color.rgb(3,7,18));
        FrameLayout frame=new FrameLayout(this);
        ImageView wallpaper=new ImageView(this); wallpaper.setImageResource(com.cog.countryofgamers.R.drawable.cog_background); wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP); frame.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackgroundColor(0x99020816); frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(18),dp(18),dp(110)); scroll.addView(root);
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL); brand.setPadding(dp(14),dp(12),dp(14),dp(12)); brand.setBackground(panelBg());
        TextView logo=new TextView(this); logo.setText("COG"); logo.setTextColor(Color.WHITE); logo.setTextSize(32); logo.setTypeface(Typeface.DEFAULT,Typeface.BOLD_ITALIC); brand.addView(logo,new LinearLayout.LayoutParams(-2,-2));
        LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); words.setPadding(dp(12),0,0,0); TextView name=label("COUNTRY OF GAMERS",15,true); TextView sub=label("FLOATING CONTROL CENTER • HAEKALXX",10,false); sub.setTextColor(cyan); words.addView(name); words.addView(sub); brand.addView(words); root.addView(brand,margin(-1,-2,0,0,0,12));
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL); stats.setBackground(panelBg()); stats.setPadding(dp(8),dp(14),dp(8),dp(14)); String[] statNames={"FPS","CPU","RAM","PING"}; String[] statVals={"60*","—","—","—"}; for(int i=0;i<4;i++){LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER);cell.setOrientation(LinearLayout.VERTICAL);cell.addView(label(statNames[i],10,true));TextView v=label(statVals[i],16,true);v.setTextColor(cyan);cell.addView(v);stats.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}root.addView(stats,margin(-1,-2,0,0,0,18));
        LinearLayout hero=new LinearLayout(this); hero.setOrientation(LinearLayout.VERTICAL); hero.setGravity(Gravity.CENTER); hero.setPadding(dp(12),dp(28),dp(12),dp(28)); hero.setBackground(panelBg()); TextView glyph=label("◈",68,true);glyph.setTextColor(cyan);hero.addView(glyph);TextView title=label("NEXT LEVEL\nGAMING EXPERIENCE",20,true);title.setGravity(Gravity.CENTER);hero.addView(title);TextView tagline=label("PLAY  •  CONTROL  •  WIN",11,true);tagline.setTextColor(0xffa5b8e8);tagline.setPadding(0,dp(12),0,0);hero.addView(tagline);root.addView(hero,margin(-1,-2,0,0,0,18));
        LinearLayout quick=new LinearLayout(this);quick.setOrientation(LinearLayout.VERTICAL);quick.setPadding(dp(14),dp(14),dp(14),dp(14));quick.setBackground(panelBg());quick.addView(label("FLOAT APPS",16,true));quick.addView(label("Buka aplikasi asli sambil COG tetap aktif.",12,false));LinearLayout apps=new LinearLayout(this);apps.setOrientation(LinearLayout.HORIZONTAL);String[] names={"WhatsApp","Telegram","Chrome","YouTube"};String[] pkgs={"com.whatsapp","org.telegram.messenger","com.android.chrome","com.google.android.youtube"};for(int i=0;i<names.length;i++){final String pkg=pkgs[i];Button a=action(names[i],false);a.setTextSize(10);apps.addView(a,new LinearLayout.LayoutParams(0,dp(44),1));a.setOnClickListener(v->launch(pkg));}quick.addView(apps);root.addView(quick,margin(-1,-2,0,0,0,18));
        Button start=action("▶  START COG CONTROL CENTER",true);root.addView(start,margin(-1,dp(54),0,0,0,10));start.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){Toast.makeText(this,"Izinkan COG tampil di atas aplikasi lain dulu",Toast.LENGTH_LONG).show();permission();return;}Intent i=new Intent(this,FloatingService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"COG Floating dijalankan",Toast.LENGTH_SHORT).show();});
        Button perm=action("IZINKAN DISPLAY OVER OTHER APPS",false);root.addView(perm,margin(-1,dp(46),0,0,0,10));perm.setOnClickListener(v->permission());Button stop=action("■  STOP COG OVERLAY",false);root.addView(stop,margin(-1,dp(46),0,0,0,14));stop.setOnClickListener(v->{Intent service=new Intent(this,FloatingService.class);boolean stopped=stopService(service);Toast.makeText(this,stopped?"Perintah STOP dikirim. Semua overlay akan dilepas.":"Service overlay tidak sedang berjalan.",Toast.LENGTH_LONG).show();});TextView note=label("*FPS adalah label target visual, bukan pengukuran FPS game. Statistik yang belum tersedia tidak akan dibuat-buat.",10,false);note.setGravity(Gravity.CENTER);note.setTextColor(0xff9ba9c8);root.addView(note);
        // Real interactive navigation sits above the decorative navigation art in the wallpaper.
        LinearLayout bottomNav=new LinearLayout(this);
        bottomNav.setOrientation(LinearLayout.HORIZONTAL);
        bottomNav.setGravity(Gravity.CENTER);
        bottomNav.setPadding(dp(8),dp(8),dp(8),dp(8));
        bottomNav.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,new int[]{0xee050d20,0xf50a1230}));
        String[] navLabels={"◎\nCROSSHAIR","▦\nMACRO","◆\nHOME","♙\nPROFILE"};
        String[] navPages={"CROSSHAIR","MACRO","HOME","PROFILE"};
        for(int n=0;n<navLabels.length;n++){
            final String destination=navPages[n];
            Button tab=action(navLabels[n],destination.equals("HOME"));
            tab.setTextSize(10);
            tab.setMinHeight(dp(58));
            tab.setPadding(dp(2),dp(2),dp(2),dp(2));
            bottomNav.addView(tab,new LinearLayout.LayoutParams(0,dp(62),1));
            tab.setOnClickListener(v->{
                if(destination.equals("HOME")){scroll.smoothScrollTo(0,0);return;}
                if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){Toast.makeText(this,"Izinkan tampil di atas aplikasi untuk membuka halaman COG",Toast.LENGTH_LONG).show();permission();return;}
                Intent control=new Intent(this,FloatingService.class);control.putExtra("open_page",destination);
                if(Build.VERSION.SDK_INT>=26)startForegroundService(control);else startService(control);
            });
        }
        FrameLayout.LayoutParams navLp=new FrameLayout.LayoutParams(-1,dp(78),Gravity.BOTTOM);
        frame.addView(bottomNav,navLp);
        setContentView(frame);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);
    }
    private void permission(){if(Build.VERSION.SDK_INT>=23)startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}
    private void launch(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Toast.makeText(this,"Aplikasi tidak ditemukan",Toast.LENGTH_SHORT).show();return;}startActivity(i);}catch(Exception e){Toast.makeText(this,"Tidak bisa membuka aplikasi",Toast.LENGTH_SHORT).show();}}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout.LayoutParams margin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable panelBg(){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{0xee07172b,0xf0060b1b,0xee100a27});d.setCornerRadius(dp(18));d.setStroke(dp(1),0xff087fbd);return d;}
    private Button action(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(13);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,primary?new int[]{0xff006dcb,0xff5520b7}:new int[]{0xff0b233b,0xff18102c});d.setCornerRadius(dp(12));d.setStroke(dp(1),primary?cyan:purple);b.setBackground(d);return b;}
}
