package com.cog.countryofgamers;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private final int cyan=Color.rgb(0,229,255), purple=Color.rgb(164,75,255), ink=0xff06101f;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xff030713); getWindow().setNavigationBarColor(0xff030713);
        FrameLayout frame=new FrameLayout(this);
        ImageView wallpaper=new ImageView(this); wallpaper.setImageResource(R.drawable.cog_background); wallpaper.setScaleType(ImageView.ScaleType.CENTER_CROP); frame.addView(wallpaper,new FrameLayout.LayoutParams(-1,-1));
        View shade=new View(this); shade.setBackgroundColor(0xd9040713); frame.addView(shade,new FrameLayout.LayoutParams(-1,-1));
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); scroll.setClipToPadding(false); frame.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(16),dp(15),dp(16),dp(24)); scroll.addView(root);

        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL); brand.setPadding(dp(14),dp(13),dp(14),dp(13)); brand.setBackground(panelBg(true));
        TextView logo=label("COG",31,true); logo.setTextColor(Color.WHITE); logo.setShadowLayer(dp(7),0,0,cyan); brand.addView(logo);
        LinearLayout words=new LinearLayout(this); words.setOrientation(LinearLayout.VERTICAL); words.setPadding(dp(12),0,0,0);
        words.addView(label("COUNTRY OF GAMERS",16,true)); TextView sub=label("NEON BLADE  //  CONTROL SYSTEM",10,true);sub.setTextColor(cyan);words.addView(sub);brand.addView(words,new LinearLayout.LayoutParams(0,-2,1));
        TextView ver=label("3.2",11,true);ver.setTextColor(cyan);brand.addView(ver);root.addView(brand,margin(-1,-2,0,0,0,12));

        LinearLayout welcome=card(); welcome.setPadding(dp(16),dp(16),dp(16),dp(17));
        TextView over=label("SYSTEM READY  •  ANDROID OVERLAY",10,true);over.setTextColor(cyan);welcome.addView(over);
        TextView headline=label("YOUR GAME.\nYOUR CONTROL.",27,true);headline.setLineSpacing(dp(1),1f);headline.setShadowLayer(dp(5),0,0,0xff243eff);welcome.addView(headline,margin(-1,-2,0,dp(8),0,0));
        TextView desc=label("Pusat kontrol gaming dengan floating window Neon Blade, crosshair overlay, profil, dan launcher aplikasi.",12,false);desc.setTextColor(0xffc1d1ed);welcome.addView(desc);
        LinearLayout chips=new LinearLayout(this);chips.setOrientation(LinearLayout.HORIZONTAL);chips.setPadding(0,dp(13),0,0);String[] tags={"FLOATING UI","CROSSHAIR","PROFILES"};for(String tag:tags){TextView t=label(tag,9,true);t.setTextColor(cyan);t.setGravity(Gravity.CENTER);t.setPadding(dp(8),dp(7),dp(8),dp(7));GradientDrawable gd=new GradientDrawable();gd.setColor(0x3310bde8);gd.setCornerRadius(dp(8));gd.setStroke(dp(1),0xff176b91);t.setBackground(gd);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-2,-2);lp.setMargins(0,0,dp(6),0);chips.addView(t,lp);}welcome.addView(chips);root.addView(welcome,margin(-1,-2,0,0,0,12));

        LinearLayout stats=card();stats.setOrientation(LinearLayout.HORIZONTAL);stats.setPadding(dp(8),dp(13),dp(8),dp(13));String[][] data={{"FPS","TARGET 60*"},{"CPU","N/A"},{"RAM","N/A"},{"PING","N/A"}};for(String[] item:data){LinearLayout cell=new LinearLayout(this);cell.setGravity(Gravity.CENTER);cell.setOrientation(LinearLayout.VERTICAL);TextView k=label(item[0],10,true);k.setTextColor(0xffaabbd6);cell.addView(k);TextView v=label(item[1],13,true);v.setTextColor(cyan);cell.addView(v);stats.addView(cell,new LinearLayout.LayoutParams(0,-2,1));}root.addView(stats,margin(-1,-2,0,0,0,12));

        sectionLabel(root,"QUICK ACCESS","01  /  CONTROL DECK");
        LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.HORIZONTAL);
        grid.addView(feature("◎","CROSSHAIR","Overlay & posisi",()->startOverlayPage("CROSSHAIR")),new LinearLayout.LayoutParams(0,dp(112),1));
        grid.addView(feature("⌘","MACRO","Preset konfigurasi",()->startOverlayPage("MACRO")),new LinearLayout.LayoutParams(0,dp(112),1));
        grid.addView(feature("◈","PROFILE","Simpan preset",()->startOverlayPage("PROFILE")),new LinearLayout.LayoutParams(0,dp(112),1));root.addView(grid,margin(-1,-2,0,0,0,14));

        sectionLabel(root,"APP DOCK","02  /  LAUNCH INSTALLED APPS");
        LinearLayout quick=card();quick.setOrientation(LinearLayout.VERTICAL);quick.setPadding(dp(12),dp(12),dp(12),dp(12));quick.addView(label("OPEN AN APP",15,true));TextView qsub=label("Pilih aplikasi untuk dibuka. COG bisa tetap aktif sebagai overlay.",11,false);qsub.setTextColor(0xffb4c7e4);quick.addView(qsub,margin(-1,-2,0,dp(4),0,7));
        String[] names={"WhatsApp","Telegram","Chrome","YouTube","Spotify"};String[] pkgs={"com.whatsapp","org.telegram.messenger","com.android.chrome","com.google.android.youtube","com.spotify.music"};
        for(int i=0;i<names.length;i++){final String pkg=pkgs[i];Button a=action("↗   "+names[i],false);a.setGravity(Gravity.CENTER_VERTICAL|Gravity.LEFT);quick.addView(a,margin(-1,dp(42),0,0,0,6));a.setOnClickListener(v->launch(pkg));}root.addView(quick,margin(-1,-2,0,0,0,14));

        sectionLabel(root,"OVERLAY CONTROL","03  /  FLOATING WINDOW");
        Button start=action("▶   LAUNCH NEON BLADE",true);root.addView(start,margin(-1,dp(55),0,0,0,9));start.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){Toast.makeText(this,"Izinkan tampil di atas aplikasi lain dulu",Toast.LENGTH_LONG).show();permission();return;}Intent i=new Intent(this,FloatingService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"COG overlay dimulai",Toast.LENGTH_SHORT).show();});
        LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.HORIZONTAL);Button perm=action("IZINKAN OVERLAY",false);row.addView(perm,new LinearLayout.LayoutParams(0,dp(46),1));perm.setOnClickListener(v->permission());Button stop=action("STOP OVERLAY",false);LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(0,dp(46),1);sp.setMargins(dp(7),0,0,0);row.addView(stop,sp);stop.setOnClickListener(v->{stopService(new Intent(this,FloatingService.class));Toast.makeText(this,"COG overlay dihentikan",Toast.LENGTH_SHORT).show();});root.addView(row,margin(-1,-2,0,0,0,12));
        TextView note=label("*FPS hanya target visual, bukan pengukuran FPS game. CPU, RAM, dan ping yang belum tersedia ditampilkan sebagai N/A.",10,false);note.setGravity(Gravity.CENTER);note.setTextColor(0xff94a9ca);root.addView(note);
        setContentView(frame);
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);
    }
    private void startOverlayPage(String page){if(Build.VERSION.SDK_INT>=23&&!Settings.canDrawOverlays(this)){Toast.makeText(this,"Aktifkan izin overlay dahulu",Toast.LENGTH_LONG).show();permission();return;}Intent i=new Intent(this,FloatingService.class);i.putExtra("page",page);if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);Toast.makeText(this,"Buka tab "+page+" di floating control",Toast.LENGTH_SHORT).show();}
    private void sectionLabel(LinearLayout root,String title,String meta){LinearLayout r=new LinearLayout(this);r.setGravity(Gravity.CENTER_VERTICAL);TextView a=label(title,14,true);r.addView(a,new LinearLayout.LayoutParams(0,-2,1));TextView b=label(meta,9,true);b.setTextColor(cyan);r.addView(b);root.addView(r,margin(-1,-2,0,dp(2),0,8));}
    private LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setBackground(panelBg(false));return l;}
    private View feature(String icon,String title,String sub,Runnable action){LinearLayout box=card();box.setGravity(Gravity.CENTER);box.setPadding(dp(4),dp(10),dp(4),dp(8));TextView g=label(icon,27,true);g.setTextColor(cyan);g.setShadowLayer(dp(5),0,0,cyan);box.addView(g);TextView t=label(title,11,true);t.setGravity(Gravity.CENTER);box.addView(t);TextView s=label(sub,9,false);s.setTextColor(0xffaabbd6);s.setGravity(Gravity.CENTER);box.addView(s);box.setOnClickListener(v->action.run());LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)box.getLayoutParams();return box;}
    private void permission(){if(Build.VERSION.SDK_INT>=23)startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName())));}
    private void launch(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg);if(i==null){Toast.makeText(this,"Aplikasi tidak ditemukan",Toast.LENGTH_SHORT).show();return;}startActivity(i);}catch(Exception e){Toast.makeText(this,"Tidak bisa membuka aplikasi",Toast.LENGTH_SHORT).show();}}
    private int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    private LinearLayout.LayoutParams margin(int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(w<0?w:dp(w),h<0?h:dp(h));p.setMargins(dp(l),dp(t),dp(r),dp(b));return p;}
    private TextView label(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextColor(Color.WHITE);t.setTextSize(size);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private GradientDrawable panelBg(boolean header){GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.TL_BR,header?new int[]{0xf00a2638,0xf00b0c25,0xf01a0a32}:new int[]{0xee07172b,0xf0060b1b,0xee100a27});d.setCornerRadius(dp(header?20:16));d.setStroke(dp(1),header?cyan:0xff176b91);return d;}
    private Button action(String s,boolean primary){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);GradientDrawable d=new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,primary?new int[]{0xff007fc9,0xff1746cc,0xff6921c4}:new int[]{0xff0b233b,0xff11152d,0xff1a1030});d.setCornerRadius(dp(12));d.setStroke(dp(1),primary?cyan:purple);b.setBackground(d);return b;}
}
