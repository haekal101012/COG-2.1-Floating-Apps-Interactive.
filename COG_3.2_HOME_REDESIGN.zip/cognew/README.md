# COG 3.0 — Country of Gamers

Native Android Java project. Build with `gradle assembleDebug` (Android SDK API 35, Java 17, Gradle 8.7).

## Included
- Futuristic dark/cyan/purple home screen using the bundled COG background.
- Floating COG bubble and a single movable control panel.
- Functional persisted control sliders and LOW/MEDIUM/HIGH presets.
- Visual crosshair overlay with size/gap/thickness controls.
- Macro utility slots that save enabled state only; no game input automation.
- Save/load for three local profiles.
- Launcher buttons for WhatsApp, Telegram, Chrome, YouTube and Spotify.
- Device RAM/network/display/Android information where available.

FPS is not read from the game and is not claimed as a live measurement. Small-window behavior for launched apps depends on Android/OEM multitasking support.
