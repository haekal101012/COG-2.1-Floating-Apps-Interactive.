# COG — Country of Gamers (HAEKALXX)

Neon Blade Android overlay project. Android Studio/Gradle project files are at the ZIP root.

## Build
- Java 17
- Gradle 8.7
- Android Gradle Plugin 8.6.1
- `gradle assembleDebug`

## Implemented in this revision
- Removed the old floating COG bubble from service startup; panel is opened from a slim right-edge handle.
- Added a subtle animated tint pulse to the main screen background.
- Added a custom vector launcher icon.
- Added crosshair shape (Plus/X/Dot/Circle/Diamond/T), color, opacity, size, gap and thickness preferences.
- Added macro slot trigger/target/mode/interval configuration UI and local persistence.
- Added Shizuku and developer/wireless-debugging shortcuts on the APK main screen; pairing still requires Android/Shizuku user steps.
- Launcher enumerates launchable installed apps.

## Important limitations
- This ZIP has not been compiled in an Android SDK environment in this session. Run GitHub Actions to verify compilation.
- Macro options are configuration UI only; cross-app hardware-key listening, hold/release detection and touch injection are not implemented by this revision. Shizuku alone does not guarantee arbitrary cross-app input injection.
- Wireless debugging pairing cannot be silently completed by the app; the user must complete Android/Shizuku pairing steps.
- FPS/ping are not claimed as measured game telemetry.
